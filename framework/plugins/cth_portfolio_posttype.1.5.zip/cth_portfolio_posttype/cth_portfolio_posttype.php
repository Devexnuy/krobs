<?php
/*
Plugin Name: Krobs Theme Add-ons
Plugin URI: https://cththemes.com
Description: Create Portfolio posttype for our theme development
Version: 1.5
Author: CTHthemes
Author URI: http://themeforest.net/user/cththemes
Text Domain: cth-portfolio-posttype
License: GNU General Public License version 3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html
*/

function cth_register_cpt_Portfolio() {
    
    $labels = array( 
        'name' => __( 'Portfolio', 'cth-portfolio-posttype' ),
        'singular_name' => __( 'Portfolio', 'cth-portfolio-posttype' ),
        'add_new' => __( 'Add New Portfolio', 'cth-portfolio-posttype' ),
        'add_new_item' => __( 'Add New Portfolio', 'cth-portfolio-posttype' ),
        'edit_item' => __( 'Edit Portfolio', 'cth-portfolio-posttype' ),
        'new_item' => __( 'New Portfolio', 'cth-portfolio-posttype' ),
        'view_item' => __( 'View Portfolio', 'cth-portfolio-posttype' ),
        'search_items' => __( 'Search Portfolios', 'cth-portfolio-posttype' ),
        'not_found' => __( 'No Portfolios found', 'cth-portfolio-posttype' ),
        'not_found_in_trash' => __( 'No Portfolios found in Trash', 'cth-portfolio-posttype' ),
        'parent_item_colon' => __( 'Parent Portfolio:', 'cth-portfolio-posttype' ),
        'menu_name' => __( 'Portfolios', 'cth-portfolio-posttype' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'List Portfolios',
        'supports' => array( 'title', 'editor', 'thumbnail',/* 'comments', 'post-formats'*/),
        'taxonomies' => array('skill'),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 20,
        'menu_icon' => plugin_dir_url( __FILE__ ) .'assets/admin_ico_portfolio.png', 
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => true,
        'capability_type' => 'post'
    );

    register_post_type( 'Portfolio', $args );
}

//Register Portfolio 
add_action( 'init', 'cth_register_cpt_Portfolio' );


//create a custom taxonomy name it Skills for your posts

function cth_create_Skills_hierarchical_taxonomy() {

// Add new taxonomy, make it hierarchical like categories
//first do the translations part for GUI

  $labels = array(
    'name' => __( 'Skills', 'cth-portfolio-posttype' ),
    'singular_name' => __( 'Skill', 'cth-portfolio-posttype' ),
    'search_items' =>  __( 'Search Skills','cth-portfolio-posttype' ),
    'all_items' => __( 'All Skills','cth-portfolio-posttype' ),
    'parent_item' => __( 'Parent Skill','cth-portfolio-posttype' ),
    'parent_item_colon' => __( 'Parent Skill:','cth-portfolio-posttype' ),
    'edit_item' => __( 'Edit Skill','cth-portfolio-posttype' ), 
    'update_item' => __( 'Update Skill','cth-portfolio-posttype' ),
    'add_new_item' => __( 'Add New Skill','cth-portfolio-posttype' ),
    'new_item_name' => __( 'New Skill Name','cth-portfolio-posttype' ),
    'menu_name' => __( 'Skills','cth-portfolio-posttype' ),
  );     

// Now register the taxonomy

  register_taxonomy('skill',array('portfolio'), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'skills' ),
  ));

}

//Add Portfolio Skills
    
add_action( 'init', 'cth_create_Skills_hierarchical_taxonomy', 0 );

function cth_portfolio_posttype_init() {
    $plugin_dir = basename(dirname(__FILE__));
    load_plugin_textdomain( 'cth-portfolio-posttype', false, $plugin_dir . '/languages' );
}
add_action('plugins_loaded', 'cth_portfolio_posttype_init');

?>